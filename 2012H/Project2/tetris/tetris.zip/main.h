#ifndef _MAIN_H
#define _MAIN_H

#include <QtGui>
#include <QWidget>
#include <QMainWindow>

#include "game_window.h"

#endif