#include <iostream>
#include "menu/menu.h"

int main(){
	mainMenu();
	
	return 0;
}