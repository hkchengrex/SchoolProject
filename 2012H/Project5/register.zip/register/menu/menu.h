#ifndef _MENU_H
#define _MENU_H

#include <stdlib.h>

#define MAX_MENU_ITEMS 10

#define MAIN_MENU_SIZE 6

#define L2_1_MENU_SIZE 5
#define L2_2_MENU_SIZE 5
#define L2_3_MENU_SIZE 5
#define L2_4_MENU_SIZE 5
#define L2_5_MENU_SIZE 3

void mainMenu();
void l2_Menu(int item);

#endif